//
//  ContentView.swift
//  BakeBook
//
//  Created by Rayaan Ismail on 10/4/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            Color("Primary")
                .ignoresSafeArea()
            
            Dashboard()
        }
    }
}

#Preview {
    ContentView()
}

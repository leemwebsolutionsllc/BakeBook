//
//  BakeBookTests.swift
//  BakeBookTests
//
//  Created by Rayaan Ismail on 10/4/24.
//

import Testing
@testable import BakeBook

struct BakeBookTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}

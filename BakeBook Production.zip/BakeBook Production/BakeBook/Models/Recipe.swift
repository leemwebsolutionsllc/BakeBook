//import Foundation
//
//struct Recipe: Identifiable {
//    let id = UUID()
//    var name: String
//    var imageName: String
//    var variants: [String]
//    var ingredients: String
//    var instructions: String
//    var cookingTime: String
//}

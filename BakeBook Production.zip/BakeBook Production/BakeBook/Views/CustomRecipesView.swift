//import SwiftUI
//
//struct CustomRecipesView: View {
//    var body: some View {
//        VStack {
//            Text("Custom Recipes")
//                .font(.headline)
//                .fontWeight(.bold)
//                .padding(.top, 20)
//                .padding(.horizontal)
//            
//            Text("You haven’t created any custom recipes yet. You can create recipes by tapping the edit icon in the upper right corner.")
//                .font(.subheadline)
//                .foregroundColor(.gray)
//                .padding()
//        }
//    }
//}
